package id.ac.unand.fti.si.pbo;

public interface CanRequestCicilan {
    public Integer hitungCicilanPerBulan(Integer totalBelanja,Integer jumlahBulan);
}
