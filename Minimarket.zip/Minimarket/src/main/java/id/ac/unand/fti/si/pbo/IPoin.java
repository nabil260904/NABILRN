package id.ac.unand.fti.si.pbo;

public interface IPoin {
    public Integer redeemPoin(Integer jumlahPoin);
    public Integer getPoin();
}
