package id.ac.unand.fti.si.pbo;

public interface CanRequestDelivery {
    public Double hitungOngkir(Double jarakTujuan);
}
