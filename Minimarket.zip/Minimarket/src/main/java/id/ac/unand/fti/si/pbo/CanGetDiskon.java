package id.ac.unand.fti.si.pbo;

public interface CanGetDiskon {
    public Integer hitungTotalBayar(Integer jumlahBelanja);
}
